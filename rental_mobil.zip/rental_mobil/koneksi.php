<?php
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'rentalmobil'; 
$conn = new mysqli($host, $username, $password, $db_name);
?>