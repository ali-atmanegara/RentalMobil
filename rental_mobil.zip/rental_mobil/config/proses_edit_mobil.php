<?php
include "../koneksi.php";
$id = $_POST['id'];
$merk = $_POST['merk'];
$model = $_POST['model'];
$no_plat = $_POST['no_plat'];
$tarif = $_POST['tarif'];


mysqli_query($conn,"update mobil set merk='$merk', model='$model', no_plat='$no_plat', tarif='$tarif' where id_mobil='$id'");

	echo "<script> alert ('Perubahan data disimpan')
	location.replace('../data_mobil.php')</script>";	

?>