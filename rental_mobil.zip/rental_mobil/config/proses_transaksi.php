<?php
include "../koneksi.php";
$tgl_pinjam =$_POST['thn1'].'-'.$_POST['bln1'].'-'.$_POST['tgl1'];
$tgl_kembali =$_POST['thn2'].'-'.$_POST['bln2'].'-'.$_POST['tgl2'];
$tanggal_1 = strtotime($tgl_pinjam);
$tanggal_2 = strtotime($tgl_kembali);
$jarak = $tanggal_2 - $tanggal_1;
$selisih = $jarak / 60 / 60 / 24;

$id_pengguna = $_POST['id_pengguna'];
$id_mobil = $_POST['id_mobil'];

$ambil_mobil=mysqli_query($conn,"select * from mobil where id_mobil='$id_mobil'");
$x=mysqli_fetch_array($ambil_mobil);
$tarif=$x['tarif'];
$total=$tarif*$selisih;

mysqli_query($conn,"update mobil set status='2' where id_mobil='$id_mobil'");

$sql=mysqli_query($conn,"INSERT INTO transaksi VALUES ('','$tgl_pinjam','$tgl_kembali','$id_pengguna','$id_mobil','$selisih','$total','','1')");
if ($sql != 0){
	echo "<script> alert ('Data telah disimpan')
	location.replace('../transaksi_peminjaman.php')</script>";	
}
else {
	echo "<script> alert ('Gagal disimpan')
	location.replace('../transaksi_peminjaman.php')</script>";
}	

?>