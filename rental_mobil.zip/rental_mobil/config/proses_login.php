<?php

include "../koneksi.php";
$username=$_POST['username'];
$password=$_POST['password'];


$cek = mysqli_query($conn,"SELECT * FROM user WHERE username='$username' AND password='$password'");

if(mysqli_num_rows($cek)==1){

echo "<script> alert ('Login Sukses')
	location.replace('../depan_admin.php')</script>";


}else{
echo "<script> alert ('Username dan Password SALAH!!')
	location.replace('../index.php')</script>";
}


?>
