<?php
include "../koneksi.php";

mysqli_query($conn,"DELETE FROM pengguna WHERE id_pengguna='$_GET[id]'");
echo "<script> alert ('Data telah berhasil dihapus')
	location.replace('../data_pengguna.php')</script>";
?>