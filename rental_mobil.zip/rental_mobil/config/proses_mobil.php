<?php
include "../koneksi.php";
$merk = $_POST['merk'];
$model = $_POST['model'];
$no_plat = $_POST['no_plat'];
$tarif = $_POST['tarif'];

$sql=mysqli_query($conn,"INSERT INTO mobil VALUES ('','$merk','$model','$no_plat','$tarif','1')");
if ($sql != 0){
	echo "<script> alert ('Data telah disimpan')
	location.replace('../data_mobil.php')</script>";	
}
else {
	echo "<script> alert ('Gagal disimpan')
	location.replace('../input_mobil.php')</script>";
}	

?>