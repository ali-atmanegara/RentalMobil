<?php
include "../koneksi.php";
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$no_tlp = $_POST['no_tlp'];
$no_sim = $_POST['no_sim'];

$sql=mysqli_query($conn,"INSERT INTO pengguna VALUES ('','$nama','$alamat','$no_tlp','$no_sim')");
if ($sql != 0){
	echo "<script> alert ('Data telah disimpan')
	location.replace('../data_pengguna.php')</script>";	
}
else {
	echo "<script> alert ('Gagal disimpan')
	location.replace('../input_pengguna.php')</script>";
}	

?>