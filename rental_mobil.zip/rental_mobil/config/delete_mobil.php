<?php
include "../koneksi.php";

mysqli_query($conn,"DELETE FROM mobil WHERE id_mobil='$_GET[id]'");
echo "<script> alert ('Data telah berhasil dihapus')
	location.replace('../data_mobil.php')</script>";
?>