<?php
include "../koneksi.php";
$id = $_POST['id'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$no_tlp = $_POST['no_tlp'];
$no_sim = $_POST['no_sim'];


mysqli_query($conn,"update pengguna set nama_pengguna='$nama', alamat='$alamat', no_tlp='$no_tlp', no_sim='$no_sim' where id_pengguna='$id'");

	echo "<script> alert ('Perubahan data disimpan')
	location.replace('../data_pengguna.php')</script>";	

?>