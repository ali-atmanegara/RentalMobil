<?php
include "../koneksi.php";
$id = $_GET['id'];


mysqli_query($conn,"update transaksi set status_transaksi='2' where id_transaksi='$id'");

$ambil=mysqli_query($conn,"select * from transaksi where id_transaksi='$id'");
$data=mysqli_fetch_array($ambil);
$id_mobil=$data['id_mobil'];

mysqli_query($conn,"update mobil set status='1' where id_mobil='$id_mobil'");

	echo "<script> alert ('Transaksi selesai')
	location.replace('../transaksi_peminjaman.php')</script>";	

?>